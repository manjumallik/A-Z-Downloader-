package video.downloader.videodownloader.five.activity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.format.Formatter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * BrowserDownloaderActivity
 *
 * Handles file download requests initiated from a browser or external intent.
 * Shows download dialogs for:
 *   - New files (not yet downloaded)
 *   - Files currently downloading (with live progress)
 *   - Already downloaded files (open/re-download)
 *
 * Typical flow:
 *   1. Receives an intent with a URL (via ACTION_VIEW or extra "url").
 *   2. Determines the file extension; if none is found, finishes immediately.
 *   3. Checks whether the file has been downloaded before.
 *      - Never downloaded → showNewDownloadDialog()
 *      - Downloaded & file exists → showAlreadyDownloadedDialog()
 *      - In progress / partially downloaded → showDownloadProgressDialog()
 */
public class BrowserDownloaderActivity extends BasePermissionActivity {

    // -------------------------------------------------------------------------
    // Fields
    // -------------------------------------------------------------------------

    /** The download Record being tracked (null for new downloads). */
    @Nullable
    private Record currentRecord;

    /** Shows formatted "downloaded / total" size for in-progress downloads. */
    @Nullable
    private TextView tvDownloadedSize;

    /** Shows download speed (bytes/sec). */
    @Nullable
    private TextView tvDownloadSpeed;

    /** Progress bar for in-progress downloads. */
    @Nullable
    private ProgressBar progressBar;

    /** The AlertDialog currently displayed (in-progress download). */
    @Nullable
    private AlertDialog progressDialog;

    // -------------------------------------------------------------------------
    // Dialog: dismiss-and-finish helpers
    // -------------------------------------------------------------------------

    /** Dismisses a dialog and finishes the activity. */
    private void dismissAndFinish(@NonNull DialogInterface dialog) {
        dialog.dismiss();
        finish();
    }

    // -------------------------------------------------------------------------
    // Network helper
    // -------------------------------------------------------------------------

    /**
     * Fetches the remote file size in bytes.
     *
     * First attempts a HEAD request (Content-Length header).
     * Falls back to opening an InputStream and counting available/read bytes.
     *
     * @param urlString Remote URL string.
     * @return File size in bytes, or 0 if it could not be determined.
     * @throws IOException on network failure.
     */
    private long fetchRemoteFileSize(@NonNull String urlString) throws IOException {
        // --- Attempt 1: HEAD request via Content-Length header ---
        try {
            HttpURLConnection connection = (HttpURLConnection) new URL(urlString).openConnection();
            connection.setRequestProperty("Accept-Encoding", "identity");
            int contentLength = connection.getContentLength();
            connection.disconnect();
            if (contentLength > 0) {
                return (long) contentLength;
            }
        } catch (Exception ignored) {
            // Fall through to the streaming fallback.
        }

        // --- Attempt 2: Stream and count bytes ---
        long totalBytes = 0;
        try (java.io.InputStream stream = new URL(urlString).openStream()) {
            int available = stream.available();
            if (available > 0) {
                return (long) available;
            }
            // Read in 10 KB chunks.
            byte[] buffer = new byte[10240];
            int read;
            while ((read = stream.read(buffer)) != -1) {
                totalBytes += read;
            }
        } catch (Exception ignored) {
            // Size remains 0; caller should handle gracefully.
        }
        return totalBytes;
    }

    // -------------------------------------------------------------------------
    // Async file-size loader (runs on a background thread; updates TextView)
    // -------------------------------------------------------------------------

    /**
     * Asynchronously resolves the remote file size and updates the given TextView.
     *
     * @param urlString  Remote URL.
     * @param sizeLabel  TextView to update on the main thread.
     */
    private void loadAndDisplayFileSize(@NonNull String urlString,
                                        @NonNull TextView sizeLabel) {
        BackgroundExecutor.execute(() -> {
            try {
                long bytes = fetchRemoteFileSize(urlString);
                if (bytes > 0) {
                    final String formatted = Formatter.formatFileSize(this, bytes);
                    runOnUiThread(() -> sizeLabel.setText(formatted));
                }
            } catch (IOException e) {
                // Silently ignore; the label keeps its loading placeholder text.
            }
        });
    }

    // -------------------------------------------------------------------------
    // Dialog: new download
    // -------------------------------------------------------------------------

    /**
     * Shows a dialog for a URL that has not been downloaded before.
     * Displays the file name, type icon, and asynchronously-loaded file size.
     *
     * @param context   Context for dialog and resource access.
     * @param url       Remote URL of the file.
     * @param extension File extension (e.g. "mp4").
     */
    public void showNewDownloadDialog(@NonNull Context context,
                                      @NonNull String url,
                                      @NonNull String extension) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        View dialogView = LayoutInflater.from(context)
                .inflate(R.layout.dialog_download_info, (ViewGroup) null);

        int fileType = FileTypeResolver.resolve(extension);
        String mimeType = MimeTypeMap.getSingleton()
                .getMimeTypeFromExtension(extension);
        String displayName = DownloadUtils.buildDisplayName(context, url, url,
                fileType, mimeType, null, "");

        ((TextView) dialogView.findViewById(R.id.tv_file_name)).setText(displayName);
        bindFileTypeIcon(fileType,
                (ImageView) dialogView.findViewById(R.id.iv_file_type));

        TextView tvSize = (TextView) dialogView.findViewById(R.id.tv_file_size);
        tvSize.setText(context.getString(R.string.loading));
        loadAndDisplayFileSize(url, tvSize);

        builder.setTitle(context.getString(R.string.download_title));
        builder.setPositiveButton(
                context.getString(R.string.btn_download).toUpperCase(),
                null /* set below after show() */);
        builder.setNegativeButton(
                context.getString(R.string.btn_cancel).toUpperCase(),
                (dialog, which) -> dismissAndFinish(dialog));
        builder.setOnDismissListener(dialog -> finish());
        builder.setView(dialogView);

        AlertDialog dialog = showDialog(context, builder);

        // Override positive button so we can request permissions first.
        Button downloadBtn = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
        if (downloadBtn != null) {
            downloadBtn.setOnClickListener(v -> {
                if (PermissionUtils.requestStoragePermission(this,
                        () -> startDownload(dialog, url, extension,
                                mimeType, fileType, displayName))) {
                    startDownload(dialog, url, extension, mimeType,
                            fileType, displayName);
                }
            });
        }
    }

    /**
     * Starts the actual download after permissions have been granted.
     */
    private void startDownload(@NonNull DialogInterface dialog,
                                @NonNull String url,
                                @NonNull String extension,
                                @Nullable String mimeType,
                                int fileType,
                                @NonNull String displayName) {
        AnalyticsTracker.track(this, "intent_page", "url_" + url);
        DownloadQueueManager.getInstance(getApplicationContext()).start();
        DownloadHelper.enqueueDownload(this,
                DownloadRequest.build(this, url, "", fileType, displayName));
        dialog.dismiss();
        DownloadHelper.notifyUser(this);
    }

    // -------------------------------------------------------------------------
    // Dialog: already downloaded
    // -------------------------------------------------------------------------

    /**
     * Shows a dialog when the file has already been downloaded and exists on disk.
     * Offers "Open" and "Re-download" actions.
     *
     * @param context Context.
     * @param record  The existing download record.
     */
    public void showAlreadyDownloadedDialog(@NonNull Context context,
                                             @NonNull Record record) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        View dialogView = LayoutInflater.from(context)
                .inflate(R.layout.dialog_download_info, (ViewGroup) null);

        ((TextView) dialogView.findViewById(R.id.tv_file_name)).setText(record.getFileName());
        bindFileTypeIcon(record.getFileType(),
                (ImageView) dialogView.findViewById(R.id.iv_file_type));

        long size = record.getFileSizeBytes();
        if (size <= 0 && record.getLocalFile(context).exists()) {
            size = record.getLocalFile(context).length();
            record.updateFileSizeBytes(size);
        }
        ((TextView) dialogView.findViewById(R.id.tv_file_size))
                .setText(size <= 0 ? "" : Formatter.formatFileSize(context, size));

        builder.setTitle(context.getString(R.string.dialog_title_already_downloaded));
        // "Open" button
        builder.setPositiveButton(
                context.getString(R.string.btn_open).toUpperCase(),
                (dialog, which) -> DownloadHelper.openFile(context, record));
        // "Re-download" button
        builder.setNeutralButton(
                context.getString(R.string.btn_redownload).toUpperCase(),
                (dialog, which) -> {
                    if (PermissionUtils.requestStoragePermission(this,
                            () -> reDownloadRecord(dialog, record))) {
                        reDownloadRecord(dialog, record);
                    }
                });
        builder.setOnDismissListener(dialog -> finish());
        builder.setView(dialogView);

        showDialog(context, builder);
    }

    private void reDownloadRecord(@NonNull DialogInterface dialog,
                                  @NonNull Record record) {
        DownloadHelper.updateAndEnqueue(this, record);
        record.setDownloadStatus(DownloadStatus.QUEUED);
        DownloadHelper.enqueueDownload(this, record);
        dialog.dismiss();
        DownloadHelper.notifyUser(this);
    }

    // -------------------------------------------------------------------------
    // Dialog: download in progress
    // -------------------------------------------------------------------------

    /**
     * Shows a dialog for a file whose download is currently in progress.
     * Displays live progress (size downloaded, total size, speed, progress bar).
     *
     * @param context Context.
     * @param record  The in-progress download record.
     */
    public void showDownloadProgressDialog(@NonNull Context context,
                                            @NonNull Record record) {
        this.currentRecord = record;

        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        View dialogView = LayoutInflater.from(context)
                .inflate(R.layout.dialog_download_info, (ViewGroup) null);

        ((TextView) dialogView.findViewById(R.id.tv_file_name)).setText(record.getFileName());
        bindFileTypeIcon(record.getFileType(),
                (ImageView) dialogView.findViewById(R.id.iv_file_type));

        this.progressBar = (ProgressBar) dialogView.findViewById(R.id.progress_bar);
        this.progressBar.setVisibility(View.VISIBLE);

        this.tvDownloadSpeed = (TextView) dialogView.findViewById(R.id.tv_download_speed);
        this.tvDownloadSpeed.setVisibility(View.VISIBLE);

        this.tvDownloadedSize = (TextView) dialogView.findViewById(R.id.tv_file_size);

        // Populate with any already-known progress.
        int taskId = DownloadTaskIdResolver.resolve(record.getUrl(), record.getLocalPath(this));
        long downloaded = DownloadQueueManager.getInstance().getDownloadedBytes(taskId);
        long total = DownloadQueueManager.getInstance().getTotalBytes(taskId);
        long speed = SpeedTracker.getSpeedBytesPerSec(record.getLocalPath(this), downloaded);
        if (speed < 0) speed = 0;

        updateProgressViews(downloaded, total, speed);

        builder.setTitle(context.getString(R.string.dialog_title_downloading));
        builder.setPositiveButton(
                context.getString(R.string.btn_view_in_files).toUpperCase(),
                (dialog, which) -> {
                    AnalyticsTracker.track(context, "Downloading_dialog", "touch_view");
                    Intent intent = new Intent(context, FilesActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    intent.putExtra("position", 1);
                    intent.putExtra("curRecordId", record.getId());
                    context.startActivity(intent);
                    progressDialog.dismiss();
                });
        builder.setNegativeButton(
                context.getString(R.string.btn_cancel_download).toUpperCase(),
                (dialog, which) -> progressDialog.dismiss());
        builder.setNeutralButton(
                context.getString(R.string.btn_cancel).toUpperCase(),
                (dialog, which) -> {
                    progressDialog.dismiss();
                    DownloadQueueManager.getInstance().pause(
                            DownloadTaskIdResolver.resolve(
                                    record.getUrl(), record.getLocalPath(this)));
                });
        builder.setOnDismissListener(dialog -> finish());
        builder.setView(dialogView);

        this.progressDialog = showDialog(context, builder);
    }

    /**
     * Updates progress UI elements.
     *
     * @param downloaded Bytes downloaded so far.
     * @param total      Total file size in bytes (0 if unknown).
     * @param speed      Current download speed in bytes/sec.
     */
    private void updateProgressViews(long downloaded, long total, long speed) {
        if (progressBar != null && total > 0) {
            progressBar.setProgress((int) ((downloaded * 100.0) / total));
        }
        if (tvDownloadedSize != null && total > 0) {
            tvDownloadedSize.setText(
                    Formatter.formatFileSize(this, downloaded)
                            + " / " + Formatter.formatFileSize(this, total));
        }
        if (tvDownloadSpeed != null) {
            tvDownloadSpeed.setText(speed == 0 ? "" :
                    Formatter.formatFileSize(this, speed) + "/s");
        }
    }

    // -------------------------------------------------------------------------
    // EventBus: live download progress updates
    // -------------------------------------------------------------------------

    /**
     * Receives real-time download progress events from the download service.
     * Updates the progress dialog UI if it is currently visible.
     *
     * @param event Progress event containing bytes downloaded, total, speed, and status.
     */
    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onDownloadProgressEvent(DownloadProgressEvent event) {
        if (TextUtils.isEmpty(event.getLocalPath())
                || progressBar == null
                || currentRecord == null) {
            return;
        }
        if (!event.getLocalPath().equals(currentRecord.getLocalPath(this))) {
            return; // Event is for a different file; ignore.
        }

        // Prefer the record's stored total size if the event doesn't carry it.
        if (event.getTotalBytes() <= 0) {
            event.setTotalBytes(currentRecord.getFileSizeBytes());
        }

        updateProgressViews(event.getDownloadedBytes(),
                event.getTotalBytes(),
                event.getSpeedBytesPerSec());

        // Handle terminal states.
        switch (event.getStatus()) {
            case DownloadStatus.FAILED:
                if (progressDialog != null) progressDialog.dismiss();
                try {
                    Snackbar.make(
                            getWindow().getDecorView(),
                            getString(R.string.download_failed, currentRecord.getFileName()),
                            Snackbar.LENGTH_LONG
                    ).show();
                } catch (Exception e) {
                    Toast.makeText(this,
                            getString(R.string.download_failed, currentRecord.getFileName()),
                            Toast.LENGTH_LONG).show();
                }
                break;

            case DownloadStatus.COMPLETED:
                if (progressDialog != null) progressDialog.dismiss();
                break;
        }
    }

    // -------------------------------------------------------------------------
    // File type icon binding
    // -------------------------------------------------------------------------

    /**
     * Sets the appropriate icon on the given ImageView for the resolved file type.
     *
     * @param fileType  Integer file-type constant (from FileTypeResolver).
     * @param imageView Target ImageView.
     */
    private void bindFileTypeIcon(int fileType, @NonNull ImageView imageView) {
        switch (fileType) {
            case FileTypeResolver.TYPE_VIDEO:
                imageView.setImageResource(R.drawable.ic_file_video);
                break;
            case FileTypeResolver.TYPE_AUDIO:
                imageView.setImageResource(R.drawable.ic_file_audio);
                break;
            case FileTypeResolver.TYPE_IMAGE:
                imageView.setImageResource(R.drawable.ic_file_image);
                break;
            case FileTypeResolver.TYPE_DOCUMENT:
                imageView.setImageResource(R.drawable.ic_file_document);
                break;
            case FileTypeResolver.TYPE_ARCHIVE:
                imageView.setImageResource(R.drawable.ic_file_archive);
                break;
            default:
                imageView.setImageResource(R.drawable.ic_file_generic);
                break;
        }
    }

    // -------------------------------------------------------------------------
    // Lifecycle
    // -------------------------------------------------------------------------

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WindowUtils.setTransparentStatusBar(this);
        ThemeUtils.applyTheme(this);
        setContentView(R.layout.activity_browser_downloader);

        Intent intent = getIntent();
        if (intent == null) {
            finish();
            return;
        }

        // Resolve URL from intent data or explicit extra.
        String url = intent.getDataString();
        if (TextUtils.isEmpty(url)) {
            url = intent.getStringExtra("url");
            AnalyticsTracker.track(this, "intent_page_url", url);
        }
        if (TextUtils.isEmpty(url)) {
            finish();
            return;
        }

        // Require a valid file extension.
        String extension = FileUtils.getExtension(url);
        if (TextUtils.isEmpty(extension)) {
            AnalyticsTracker.track(this, "intent_page", "no_extension");
            finish();
            return;
        }

        // Route to the appropriate dialog.
        Record existingRecord = DownloadDatabase.getInstance().findByUrl(this, url);
        if (existingRecord == null) {
            // Brand-new download.
            showNewDownloadDialog(this, url, extension);
            return;
        }

        AnalyticsTracker.track(this, "intent_page", "already_download");
        if (existingRecord.getLocalFile(this).exists()) {
            showAlreadyDownloadedDialog(this, existingRecord);
        } else {
            showDownloadProgressDialog(this, existingRecord);
            // Auto-resume if the download is in a resumable state.
            int downloadStatus = DownloadQueueManager.getInstance().getStatus(
                    existingRecord.getUrl(), existingRecord.getLocalPath(this));
            if (isResumableStatus(downloadStatus)
                    && PermissionUtils.requestStoragePermission(this,
                    () -> DownloadQueueManager.getInstance().enqueue(this, existingRecord))) {
                DownloadQueueManager.getInstance().enqueue(this, existingRecord);
            }
        }
    }

    /**
     * Returns true for download statuses that allow a download to be resumed/restarted.
     */
    private boolean isResumableStatus(int status) {
        return status == DownloadStatus.IDLE
                || status == DownloadStatus.PAUSED
                || status == DownloadStatus.FAILED
                || status == DownloadStatus.QUEUED
                || status == DownloadStatus.UNKNOWN;
    }

    // -------------------------------------------------------------------------
    // Utility
    // -------------------------------------------------------------------------

    /** Builds and shows an AlertDialog, applying the app theme. */
    private AlertDialog showDialog(@NonNull Context context,
                                   @NonNull AlertDialog.Builder builder) {
        AlertDialog dialog = builder.create();
        ThemeUtils.applyDialogTheme(context, dialog);
        dialog.show();
        return dialog;
    }
}
