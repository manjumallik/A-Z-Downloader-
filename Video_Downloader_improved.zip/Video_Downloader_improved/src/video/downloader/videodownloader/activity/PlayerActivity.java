package video.downloader.videodownloader.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.io.File;

/**
 * PlayerActivity
 *
 * Extends the base PlayerActivity2 to add app-specific behaviour:
 *
 * - Playback analytics (reporting play completion and failures).
 * - Error recovery:
 *   (a) Prompt to convert the file to MP4 using FFmpeg (for unsupported codecs).
 *   (b) Prompt to try another player / give feedback.
 * - A "convert to MP4" background job using FFmpeg.
 *
 * <h3>Error-Recovery Flow</h3>
 * <pre>
 * onPlaybackError()
 *   │
 *   ├─ [file already marked failed] → showFeedbackOrPlayerDialog()
 *   └─ [first failure]              → showConvertOrCancelDialog()
 *                                         │
 *                                         └─ [user chooses Convert]
 *                                              │
 *                                              ├─ convertToMp4()  (background)
 *                                              │     ├─ success → rename file, finish
 *                                              │     └─ failure → showFeedbackOrPlayerDialog()
 *                                              └─ convertingDialog (dismisses when done)
 * </pre>
 */
public final class PlayerActivity extends PlayerActivity2 {

    // -------------------------------------------------------------------------
    // Companion / static state
    // -------------------------------------------------------------------------

    /**
     * True while the converting-to-MP4 background job is running.
     * Prevents concurrent conversion jobs.
     */
    private static volatile boolean isConverting = false;

    /**
     * Set to true once the activity has intentionally navigated away (e.g. to
     * FilesActivity or FeedbackActivity). Prevents onStop from triggering
     * spurious back-navigation.
     */
    private static boolean isNavigatingAway = false;

    // -------------------------------------------------------------------------
    // Instance state
    // -------------------------------------------------------------------------

    /** Bottom sheet shown while an FFmpeg conversion is in progress. */
    @Nullable
    private BottomSheetDialog convertingBottomSheet;

    // -------------------------------------------------------------------------
    // Public accessors (used by Companion-pattern callers)
    // -------------------------------------------------------------------------

    public static boolean isConverting() {
        return isConverting;
    }

    public static void setNavigatingAway(boolean value) {
        isNavigatingAway = value;
    }

    // -------------------------------------------------------------------------
    // PlayerActivity2 overrides
    // -------------------------------------------------------------------------

    /**
     * Called by the base class when playback fails.
     *
     * @param recordId Internal ID of the Record that failed.
     * @param errorInfo Human-readable error description from the player.
     * @return true to indicate the error was handled here.
     */
    @Override
    public boolean onPlaybackError(long recordId, @NonNull String errorInfo) {
        try {
            Record record = DownloadDatabase.getInstance().findById(this, recordId);
            if (record == null) return true;

            AnalyticsTracker.trackError(this, record.getFileName(),
                    record.getUrl(), errorInfo);
            AnalyticsTracker.track(this, "play_failed_count", "play_failed");

            if (record.hasBeenMarkedFailed()) {
                showFeedbackOrPlayerDialog();
            } else {
                showConvertOrCancelDialog(record);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return true;
    }

    /**
     * Returns the Activity class to launch when the user asks to play
     * the "next" video.
     */
    @Override
    public Class<?> getNextActivityClass() {
        return NextActivity.class;
    }

    /**
     * Called by the base class when a video finishes playing successfully.
     * Updates play stats in the database and fires analytics events.
     *
     * @param recordId  Internal Record ID.
     * @param playDuration Duration played in milliseconds.
     */
    @Override
    public void onPlaybackCompleted(final long recordId, final int playDuration) {
        BackgroundExecutor.execute(() -> recordPlaybackCompletion(recordId, playDuration));
    }

    // -------------------------------------------------------------------------
    // Playback-completion logic
    // -------------------------------------------------------------------------

    private void recordPlaybackCompletion(long recordId, int playDuration) {
        Record record = DownloadDatabase.getInstance().findById(this, recordId);
        if (record == null) return;

        record.setPlayDuration(playDuration);
        record.setHasBeenPlayed(true);
        DownloadDatabase.getInstance().update(this, record);

        EventBus.getDefault().post(new PlaybackCompletedEvent(record.getId(), record.getUrl()));

        if (record.hasBeenMarkedFailed()) {
            AnalyticsTracker.track(this, "play_failed_count", "play_suc");
        }

        AnalyticsTracker.track(this, "play_done_event", "play_done");
        AnalyticsTracker.track(this, "all_user_count", "done_play");

        if (isNewUser()) {
            AnalyticsTracker.track(this, "first_process", "done_play");
            AnalyticsTracker.track(this, "bq_report_newuser", "done_play");
        }
    }

    private boolean isNewUser() {
        return androidx.core.app.ActivityCompat.checkSelfPermission(this,
                android.Manifest.permission.READ_EXTERNAL_STORAGE)
                == android.content.pm.PackageManager.PERMISSION_GRANTED;
    }

    // -------------------------------------------------------------------------
    // Error-recovery dialogs
    // -------------------------------------------------------------------------

    /**
     * Shows "Convert to MP4 / Cancel" bottom sheet.
     * This is shown on the first playback failure for a file.
     */
    private void showConvertOrCancelDialog(@NonNull Record record) {
        BottomSheetDialog sheet = BottomSheetDialog.newInstance(getSupportFragmentManager());
        sheet.setCancelable(true);
        sheet.setLayout(R.layout.sheet_convert_or_cancel);
        sheet.setExpandRatio(0.4f);
        sheet.setOnBindViewCallback(view -> {
            view.findViewById(R.id.btn_convert).setOnClickListener(v -> {
                AnalyticsTracker.track(this, "play_failed_count", "convert_click");
                sheet.dismissAllowingStateLoss();
                showConvertingProgressSheet(record);
                startFfmpegConversion(record);
            });
            view.findViewById(R.id.btn_close).setOnClickListener(v -> {
                sheet.dismissAllowingStateLoss();
                finish();
            });
        });
        try {
            sheet.show();
            AnalyticsTracker.track(this, "play_failed_count", "play_failed_2_show");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Shows "Send Feedback / Try Another Player / Cancel" bottom sheet.
     * Shown when a file has already been through conversion or on repeated failures.
     */
    private void showFeedbackOrPlayerDialog() {
        BottomSheetDialog sheet = BottomSheetDialog.newInstance(getSupportFragmentManager());
        sheet.setCancelable(true);
        sheet.setLayout(R.layout.sheet_feedback_or_player);
        sheet.setExpandRatio(0.4f);
        sheet.setOnBindViewCallback(view -> {
            view.findViewById(R.id.btn_feedback).setOnClickListener(v -> {
                AnalyticsTracker.track(this, "play_failed_count", "feedback_click");
                sheet.dismissAllowingStateLoss();
                new FeedbackHelper().openFeedbackForm(this, FeedbackType.PLAYBACK_ERROR, "");
                isNavigatingAway = true;
                finish();
            });
            view.findViewById(R.id.btn_try_other_player).setOnClickListener(v -> {
                AnalyticsTracker.track(this, "play_failed_count", "try_other_click");
                sheet.dismissAllowingStateLoss();
                isNavigatingAway = true;
                Intent intent = new Intent(this, FilesActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.putExtra("position", 2);
                startActivity(intent);
                EventBus.getDefault().post(new ChangeTabEvent(2));
                finish();
            });
            view.findViewById(R.id.btn_close).setOnClickListener(v -> {
                sheet.dismissAllowingStateLoss();
                isNavigatingAway = true;
                finish();
            });
        });
        try {
            sheet.show();
            AnalyticsTracker.track(this, "play_failed_count", "play_failed_1_show");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Shows a non-cancellable bottom sheet while FFmpeg conversion runs.
     * Dismissed automatically when conversion finishes (or fails).
     */
    private void showConvertingProgressSheet(@NonNull Record record) {
        BottomSheetDialog sheet = BottomSheetDialog.newInstance(getSupportFragmentManager());
        sheet.setCancelable(false);
        sheet.setLayout(R.layout.sheet_converting_progress);
        sheet.setExpandRatio(0.4f);
        sheet.setOnDismissCallback(() -> {
            // If conversion is still running, schedule another retry prompt.
            if (convertingBottomSheet == null && !record.hasBeenMarkedFailed()) {
                convertingBottomSheet = null;
                showConvertOrCancelDialog(record);
            }
        });
        try {
            sheet.show();
            this.convertingBottomSheet = sheet;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // -------------------------------------------------------------------------
    // FFmpeg conversion
    // -------------------------------------------------------------------------

    /**
     * Runs an FFmpeg conversion of the given Record's file to a playable MP4.
     *
     * <p>Strategy:
     * <ol>
     *   <li>Try a lossless copy: {@code -c copy} (fast, preserves quality).</li>
     *   <li>On failure, try a full re-encode: {@code -i input output.mp4}.</li>
     * </ol>
     *
     * <p>On success, the original file is deleted and the Record's filename
     * is updated to the new {@code _converted.mp4} filename.
     *
     * @param record The Record whose local file should be converted.
     */
    private void startFfmpegConversion(@NonNull Record record) {
        if (isConverting) return; // Prevent concurrent jobs.

        BackgroundExecutor.execute(() -> runFfmpegConversion(record));
    }

    private void runFfmpegConversion(@NonNull Record record) {
        isConverting = true;

        String inputPath = record.getLocalPath(this);
        if (inputPath == null) {
            isConverting = false;
            return;
        }

        // Derive output path: replace extension with "_converted.mp4".
        int dotIndex = inputPath.lastIndexOf('.');
        String basePath = dotIndex >= 0 ? inputPath.substring(0, dotIndex) : inputPath;
        String outputPath = basePath + "_converted.mp4";

        int result = -1;
        try {
            IFFmpegPlayer player = createFfmpegPlayer();

            // Attempt 1: lossless stream copy (very fast for TS/MKV → MP4).
            boolean isTsFormat = dotIndex >= 0
                    && inputPath.substring(dotIndex).equalsIgnoreCase(".ts");
            String cmd1 = isTsFormat
                    ? "-y -f mpegts -i " + inputPath + " -c copy " + outputPath
                    : "-y -i " + inputPath + " -c copy " + outputPath;
            result = player.execute(cmd1);

            // Attempt 2: full re-encode if copy failed.
            if (result != 0) {
                new File(outputPath).delete();
                result = createFfmpegPlayer().execute(
                        "-y -i " + inputPath + " " + outputPath);
            }
        } catch (Throwable t) {
            t.printStackTrace();
        }

        isConverting = false;

        final int finalResult = result;
        Handlers.main.post(() -> onConversionFinished(record, outputPath, finalResult));
    }

    /**
     * Called on the main thread after FFmpeg conversion completes or fails.
     */
    private void onConversionFinished(@NonNull Record record,
                                       @NonNull String outputPath,
                                       int resultCode) {
        if (resultCode == 0 && convertingBottomSheet != null) {
            // Success: swap the record's file to the new MP4.
            record.setHasBeenMarkedFailed(true);
            AnalyticsTracker.track(this, "play_failed_count", "convert_suc");
            record.getLocalFile(this).delete();

            String newFileName = outputPath.substring(outputPath.lastIndexOf('/') + 1);
            record.setFileName(newFileName);
            DownloadDatabase.getInstance().update(this, record);
            EventBus.getDefault().post(new RecordNameChangeEvent(record));

            isNavigatingAway = true;
            Toast.makeText(this, getString(R.string.conversion_success), Toast.LENGTH_SHORT).show();
            finish();
        } else if (convertingBottomSheet != null) {
            // Failure: inform the user and offer the feedback dialog.
            record.setHasBeenMarkedFailed(true);
            AnalyticsTracker.track(this, "play_failed_count", "convert_fail");
            DownloadDatabase.getInstance().update(this, record);
            Handlers.main.post(() -> {
                if (convertingBottomSheet != null) {
                    convertingBottomSheet.dismissAllowingStateLoss();
                    convertingBottomSheet = null;
                }
                showFeedbackOrPlayerDialog();
            });
        }
        // If convertingBottomSheet is null, the user already dismissed the UI; do nothing.
    }

    // -------------------------------------------------------------------------
    // Factory helpers
    // -------------------------------------------------------------------------

    /**
     * Creates a new {@link IFFmpegPlayer} instance via reflection so the FFmpeg
     * library can remain optional at compile time.
     */
    @NonNull
    private IFFmpegPlayer createFfmpegPlayer() throws Exception {
        Object instance = FFmpegPlayer.class.getConstructor().newInstance();
        if (!(instance instanceof IFFmpegPlayer)) {
            throw new ClassCastException("FFmpegPlayer does not implement IFFmpegPlayer");
        }
        return (IFFmpegPlayer) instance;
    }
}
