package video.downloader.videodownloader.activity;

import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;

import java.util.ArrayList;

/**
 * MainActivity
 *
 * The app entry point. Responsible for:
 *
 * 1. Verifying the app is allowed to run (licence/build-time check).
 * 2. Applying edge-to-edge window insets on Android 15+.
 * 3. Setting up the "XDownloader" white-label variant if applicable.
 * 4. Either launching the onboarding flow (first run) or navigating
 *    directly to {@link MainTabsActivity}.
 * 5. Initialising the remote-config (Firebase) listener.
 * 6. Setting the global "premium user" flag used throughout the app.
 *
 * <h3>Navigation</h3>
 * <pre>
 * MainActivity
 *   ├─ [first launch / no tab state] → onboarding / MainTabsActivity
 *   └─ [returning user]              → MainTabsActivity (with delay)
 * </pre>
 */
public class MainActivity extends ActivityCompat {

    /**
     * Whether Firebase Remote Config has finished loading.
     * Read by other components to gate features that depend on remote config.
     */
    public static boolean isRemoteConfigReady = false;

    // -------------------------------------------------------------------------
    // Lifecycle
    // -------------------------------------------------------------------------

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Abort early if the build or licence is invalid.
        if (!BuildValidator.isValid(this)) {
            finish();
            return;
        }

        // Retrieve premium/ad-free status once at start-up.
        boolean isPremium = BillingUtils.isPremiumUser(this);

        if (!isPremium) {
            // Show splash / full-screen ad before proceeding.
            showSplashAd();
        }

        setContentView(R.layout.activity_main);

        applyEdgeToEdgeInsetsIfNeeded();
        applyWhiteLabelIfNeeded();

        if (UserPreferences.get(this).getTabCount() == 0) {
            // First run or state cleared: show onboarding.
            showOnboarding(isPremium, buildOnboardingTabList());
        } else {
            // Returning user: navigate after a brief delay (allows splash ad to settle).
            navigateToMainTabsWithDelay(1000L);
        }

        initRemoteConfig();
        applyAutoDownloadFlag();
        applyPopUpPlayerFlag();

        AnalyticsTracker.track(this, "all_user_count", "splash_page_show");
    }

    // -------------------------------------------------------------------------
    // Subclass contracts
    // -------------------------------------------------------------------------

    /**
     * Returns the Activity to navigate to after the splash.
     * Subclasses may override to substitute a custom main screen.
     */
    protected Class<?> getMainActivityClass() {
        return MainTabsActivity.class;
    }

    /**
     * Returns the splash ad unit ID.
     * Subclasses may override to supply a variant-specific ID.
     */
    protected int getSplashAdUnitId() {
        return 157;
    }

    // -------------------------------------------------------------------------
    // Onboarding / navigation
    // -------------------------------------------------------------------------

    /**
     * Builds the initial tab list for the onboarding flow.
     * Falls back to a default list when the user is on the premium/ad-free build.
     */
    private ArrayList<TabDescriptor> buildOnboardingTabList() {
        if (BuildValidator.isWhiteLabel(this)) {
            // White-label: no "Discover" tab.
            return TabListBuilder.buildDefault(this, getSplashAdUnitId());
        }
        return BillingUtils.isPremiumUser(this)
                ? TabListBuilder.buildPremium(this, getSplashAdUnitId())
                : TabListBuilder.buildWithAds(this, getSplashAdUnitId());
    }

    private void showOnboarding(boolean isPremium, ArrayList<TabDescriptor> tabs) {
        OnboardingPresenter.show(this, tabs);
    }

    private void navigateToMainTabsWithDelay(long delayMs) {
        NavigationHelper.navigateDelayed(this, getMainActivityClass(), delayMs);
    }

    // -------------------------------------------------------------------------
    // Splash ad
    // -------------------------------------------------------------------------

    private void showSplashAd() {
        SplashAdPresenter.show(this, new SplashAdPresenter.Callback() {
            @Override
            public void onAdLoaded() {
                isRemoteConfigReady = true;
            }

            @Override
            public void onAdFailedToLoad(String reason) {
                RemoteConfigManager.getInstance().invalidate();
            }

            @Override
            public void onAdDismissed(int result) {
                isRemoteConfigReady = false;
                RemoteConfigManager.getInstance().invalidate();
            }
        });
    }

    // -------------------------------------------------------------------------
    // Remote config
    // -------------------------------------------------------------------------

    private void initRemoteConfig() {
        RemoteConfigManager.getInstance().fetch(this, new RemoteConfigManager.Callback() {
            @Override
            public void onReady() {
                isRemoteConfigReady = true;
            }

            @Override
            public void onError(String reason) {
                isRemoteConfigReady = true; // Proceed with cached / defaults.
            }
        });
    }

    // -------------------------------------------------------------------------
    // Flags
    // -------------------------------------------------------------------------

    /**
     * Sets the global "auto-download" flag used by the browser component to
     * decide whether to immediately enqueue detected video URLs.
     */
    private void applyAutoDownloadFlag() {
        AutoDownloadHelper.setAutoDownloadEnabled(ServiceUtils.isAutoDownloadEnabled(this));
    }

    /**
     * Sets the global "pop-up player disabled" flag so the player service
     * knows whether to show the floating player window.
     */
    private void applyPopUpPlayerFlag() {
        PopUpPlayerHelper.setEnabled(!SettingsBridge.isPopUpPlayerDisabled(this));
    }

    // -------------------------------------------------------------------------
    // Edge-to-edge
    // -------------------------------------------------------------------------

    /**
     * On Android 15+ (API 35), applies window insets so the root layout
     * is not obscured by system bars.
     */
    private void applyEdgeToEdgeInsetsIfNeeded() {
        if (Build.VERSION.SDK_INT < 35) return;

        View rootView = findViewById(R.id.root_layout);
        if (rootView == null) return;

        ViewInsetsHelper.applySystemBarInsets(rootView);
    }

    // -------------------------------------------------------------------------
    // White-label
    // -------------------------------------------------------------------------

    /**
     * If this is the "XDownloader" white-label build, updates the app-bar
     * title and hides the branded logo.
     */
    private void applyWhiteLabelIfNeeded() {
        if (!BuildValidator.isWhiteLabel(this)) return;

        View titleView = findViewById(R.id.tv_app_title);
        if (titleView != null) {
            ((android.widget.TextView) titleView).setText("XDownloader");
        }
        View logoView = findViewById(R.id.iv_app_logo);
        if (logoView != null) {
            logoView.setVisibility(View.GONE);
        }
    }
}
