package video.downloader.videodownloader.activity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.WebView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.SwitchCompat;
import androidx.appcompat.widget.Toolbar;

import com.android.billingclient.api.Purchase;
import com.google.android.gms.ads.MobileAds;

import java.util.ArrayList;
import java.util.List;

/**
 * SettingsActivity
 *
 * Provides the app Settings screen. Settings are grouped as:
 *
 * <ul>
 *   <li><b>Storage</b> – Download location (internal / SD card).</li>
 *   <li><b>Network</b> – Allow downloads over mobile data.</li>
 *   <li><b>Browser</b> – Ad-block toggle, default search engine, homepage,
 *                        clear cache / history / cookies.</li>
 *   <li><b>Media</b>   – Auto-add to gallery toggle, pop-up player toggle.</li>
 *   <li><b>App</b>     – Language, Help, Feedback, Privacy Policy,
 *                        Remove Ads purchase, in-app update.</li>
 * </ul>
 *
 * All settings are persisted via {@link PreferenceManager} (wrapping MMKV)
 * and the {@link UserPreferences} data-store.
 */
public class SettingsActivity extends BasePermissionActivity implements View.OnClickListener {

    private static final String TAG = "SettingsActivity";

    /**
     * Cached result of checking for multiple storage paths.
     * -1 = only one path (no SD card option).
     *  0 = not yet checked.
     *  1 = SD card available.
     */
    private static int sdCardAvailability = 0;

    private static final int REQUEST_CODE_STORAGE_LOCATION = 108;

    // -------------------------------------------------------------------------
    // Views
    // -------------------------------------------------------------------------

    private Toolbar toolbar;

    // Storage
    private View  vStorageLocation;
    private TextView tvStoragePath;

    // Network
    private View        vMobileData;
    private SwitchCompat swMobileData;

    // Browser
    private View        vAdBlock;
    private SwitchCompat swAdBlock;
    private TextView    tvAdBlockStatus;
    private View        vPopUpPlayer;
    private SwitchCompat swPopUpPlayer;
    private View        vSearchEngine;
    private TextView    tvSearchEngine;
    private View        vClearCache;
    private View        vClearHistory;
    private View        vClearCookies;

    // Media / Gallery
    private View        vAutoAddToGallery;
    private SwitchCompat swAutoAddToGallery;
    private TextView    tvAutoAddToGalleryStatus;

    // App
    private View     vLanguage;
    private TextView tvLanguage;
    private View     vHelp;
    private View     vFeedback;
    private View     vPrivacyPolicy;
    private TextView tvAppVersion;
    private View     vRemoveAds;
    private View     vCheckUpdate;

    // -------------------------------------------------------------------------
    // In-app billing / update helpers
    // -------------------------------------------------------------------------

    private InAppBillingLifecycle billingLifecycle;
    private UpdateChecker         updateChecker;
    private UpdateCheckerListener updateCheckerListener;
    @Nullable
    private UpdateInfo            pendingUpdateInfo;

    // -------------------------------------------------------------------------
    // Lifecycle
    // -------------------------------------------------------------------------

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WindowUtils.setTransparentStatusBar(this);
        ThemeUtils.applyTheme(this);
        getLifecycle().addObserver(new SettingLifecycleObserver(this));

        setContentView(R.layout.activity_settings);

        bindViews();
        setupToolbar();
        setupStorageSection();
        setupNetworkSection();
        setupBrowserSection();
        setupMediaSection();
        setupAppSection();
        setupBillingIfNeeded();
        checkSdCardAvailability();
        setupUpdateChecker();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (updateCheckerListener != null) {
            updateChecker.removeListener(updateCheckerListener);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Re-load privacy-policy web view if it was displayed.
        if (webViewPresenterRef != null) {
            webViewPresenterRef.resume();
            webViewPresenterRef = null;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_STORAGE_LOCATION && resultCode == RESULT_OK) {
            // Refresh the displayed storage path.
            tvStoragePath.setText(UserPreferences.get(this).getDownloadDirectory());
        }
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    // -------------------------------------------------------------------------
    // View binding
    // -------------------------------------------------------------------------

    private void bindViews() {
        toolbar             = findViewById(R.id.toolbar);
        vStorageLocation    = findViewById(R.id.view_storage_location);
        tvStoragePath       = findViewById(R.id.tv_storage_path);
        vMobileData         = findViewById(R.id.view_mobile_data);
        swMobileData        = findViewById(R.id.sw_mobile_data);
        vAdBlock            = findViewById(R.id.view_ad_block);
        swAdBlock           = findViewById(R.id.sw_ad_block);
        tvAdBlockStatus     = findViewById(R.id.tv_ad_block_status);
        vPopUpPlayer        = findViewById(R.id.view_popup_player);
        swPopUpPlayer       = findViewById(R.id.sw_popup_player);
        vSearchEngine       = findViewById(R.id.view_search_engine);
        tvSearchEngine      = findViewById(R.id.tv_search_engine);
        vClearCache         = findViewById(R.id.view_clear_cache);
        vClearHistory       = findViewById(R.id.view_clear_history);
        vClearCookies       = findViewById(R.id.view_clear_cookies);
        vAutoAddToGallery   = findViewById(R.id.view_auto_gallery);
        swAutoAddToGallery  = findViewById(R.id.sw_auto_gallery);
        tvAutoAddToGalleryStatus = findViewById(R.id.tv_auto_gallery_status);
        vLanguage           = findViewById(R.id.view_language);
        tvLanguage          = findViewById(R.id.tv_language);
        vHelp               = findViewById(R.id.view_help);
        vFeedback           = findViewById(R.id.view_feedback);
        vPrivacyPolicy      = findViewById(R.id.view_privacy_policy);
        tvAppVersion        = findViewById(R.id.tv_app_version);
        vRemoveAds          = findViewById(R.id.view_remove_ads);
        vCheckUpdate        = findViewById(R.id.view_check_update);
    }

    // -------------------------------------------------------------------------
    // Section setup
    // -------------------------------------------------------------------------

    private void setupToolbar() {
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
    }

    private void setupStorageSection() {
        tvStoragePath.setText(UserPreferences.get(this).getDownloadDirectory());
        vStorageLocation.setOnClickListener(this);
    }

    private void setupNetworkSection() {
        boolean allowMobileData = !UserPreferences.get(this).isWifiOnlyDownload();
        swMobileData.setChecked(allowMobileData);
        vMobileData.setOnClickListener(this);
    }

    private void setupBrowserSection() {
        // Ad-block toggle
        boolean adBlockEnabled = PreferenceManager.isAdBlockEnabled(this);
        swAdBlock.setChecked(adBlockEnabled);
        tvAdBlockStatus.setText(adBlockEnabled
                ? R.string.enabled
                : R.string.disabled);
        vAdBlock.setOnClickListener(this);

        // Pop-up player toggle
        swPopUpPlayer.setChecked(MmkvPrefs.getBoolean("popup_player_enabled", true));
        vPopUpPlayer.setOnClickListener(this);

        // Search engine
        refreshSearchEngineLabel(PreferenceManager.getSearchEngineIndex(this), false);
        vSearchEngine.setOnClickListener(this);

        // Clear browsing data
        vClearCache.setOnClickListener(this);
        vClearHistory.setOnClickListener(this);
        vClearCookies.setOnClickListener(this);
    }

    private void setupMediaSection() {
        boolean autoGallery = UserPreferences.get(this).isAutoAddToGallery();
        swAutoAddToGallery.setChecked(autoGallery);
        tvAutoAddToGalleryStatus.setText(autoGallery
                ? R.string.enabled
                : R.string.disabled);
        vAutoAddToGallery.setOnClickListener(this);
    }

    private void setupAppSection() {
        tvLanguage.setText(LanguageUtils.getLanguageLabel(this));
        tvAppVersion.setText(AppUtils.getVersionName(this));
        vLanguage.setOnClickListener(this);
        vHelp.setOnClickListener(this);
        vFeedback.setOnClickListener(this);
        vPrivacyPolicy.setOnClickListener(this);
        vCheckUpdate.setOnClickListener(this);

        // Observe version-name from ViewModel for remote update badge.
        SettingsViewModel vm = SettingsViewModel.get(this);
        vm.getRemoteVersionName().observe(this, version -> {
            if (!TextUtils.isEmpty(version)) {
                tvAppVersion.setText(version);
            }
        });
        vm.fetchRemoteVersionName(BuildConfig.VERSION_NAME);
    }

    private void setupBillingIfNeeded() {
        if (BillingUtils.shouldShowRemoveAds(this)) {
            vRemoveAds.setOnClickListener(this);
            billingLifecycle = new InAppBillingLifecycle(this, new PurchaseCallback());
            getLifecycle().addObserver(billingLifecycle);
        }
    }

    private void setupUpdateChecker() {
        updateChecker = new UpdateChecker(this);
        updateCheckerListener = new UpdateCheckerCallback();
        updateChecker.addListener(updateCheckerListener);
        updateChecker.checkForUpdate(BuildConfig.VERSION_NAME);
    }

    private void checkSdCardAvailability() {
        if (sdCardAvailability != 0) {
            applySdCardVisibility();
            return;
        }
        BackgroundExecutor.execute(() -> {
            List<String> paths = StorageUtils.getStoragePaths(this);
            sdCardAvailability = paths.size() > 1 ? 1 : -1;
            runOnUiThread(this::applySdCardVisibility);
        });
    }

    private void applySdCardVisibility() {
        if (sdCardAvailability == 1) {
            findViewById(R.id.view_sd_card_row).setVisibility(View.VISIBLE);
            vStorageLocation.setOnClickListener(this);
        } else {
            findViewById(R.id.view_sd_card_row).setVisibility(View.GONE);
        }
    }

    // -------------------------------------------------------------------------
    // Click handler
    // -------------------------------------------------------------------------

    @Override
    public void onClick(View view) {
        int id = view.getId();

        if (id == R.id.view_storage_location) {
            onStorageLocationClick();
        } else if (id == R.id.view_mobile_data) {
            onMobileDataToggle();
        } else if (id == R.id.view_ad_block) {
            onAdBlockToggle();
        } else if (id == R.id.view_popup_player) {
            onPopUpPlayerToggle();
        } else if (id == R.id.view_search_engine) {
            showSearchEngineDialog();
        } else if (id == R.id.view_clear_cache) {
            clearWebCache();
        } else if (id == R.id.view_clear_history) {
            confirmClearHistory();
        } else if (id == R.id.view_clear_cookies) {
            confirmClearCookies();
        } else if (id == R.id.view_auto_gallery) {
            onAutoGalleryToggle();
        } else if (id == R.id.view_language) {
            showLanguageDialog();
        } else if (id == R.id.view_help) {
            openHelp();
        } else if (id == R.id.view_feedback) {
            openFeedback();
        } else if (id == R.id.view_privacy_policy) {
            openPrivacyPolicy();
        } else if (id == R.id.view_remove_ads) {
            purchaseRemoveAds();
        } else if (id == R.id.view_check_update) {
            checkOrApplyUpdate();
        } else if (id == R.id.tv_app_version) {
            onVersionLabelTapped();
        }
    }

    // -------------------------------------------------------------------------
    // Storage
    // -------------------------------------------------------------------------

    private void onStorageLocationClick() {
        AnalyticsTracker.track(this, "setting", "location");
        if (!PermissionUtils.requestStoragePermission(this, this::openStorageChooser)) {
            openStorageChooser();
        }
    }

    private void openStorageChooser() {
        List<String> paths = StorageUtils.getStoragePaths(this);
        if (paths.size() <= 1) {
            AnalyticsTracker.track(this, "setting", "no_sd_card");
            startActivityForResult(
                    new Intent(this, FolderSelectActivity.class),
                    REQUEST_CODE_STORAGE_LOCATION);
        } else {
            AnalyticsTracker.track(this, "setting", "has_sd_card");
            Intent intent = new Intent(this, ChooseStorageActivity.class);
            intent.putStringArrayListExtra("allPath", new ArrayList<>(paths));
            startActivityForResult(intent, REQUEST_CODE_STORAGE_LOCATION);
        }
    }

    // -------------------------------------------------------------------------
    // Network
    // -------------------------------------------------------------------------

    private void onMobileDataToggle() {
        AnalyticsTracker.track(this, "setting", "wifi");
        boolean currentlyWifiOnly = UserPreferences.get(this).isWifiOnlyDownload();
        UserPreferences.get(this).setWifiOnlyDownload(!currentlyWifiOnly);
        UserPreferences.get(this).save(this);
        swMobileData.setChecked(currentlyWifiOnly); // toggled
        EventBus.getDefault().post(new MobileDataPreferenceChangedEvent());
        DownloadNotificationHelper.refresh(this);
    }

    // -------------------------------------------------------------------------
    // Browser
    // -------------------------------------------------------------------------

    private void onAdBlockToggle() {
        AnalyticsTracker.track(this, "setting", "ad_block");
        boolean nowEnabled = !PreferenceManager.isAdBlockEnabled(this);
        PreferenceManager.setAdBlockEnabled(this, nowEnabled);
        swAdBlock.setChecked(nowEnabled);
        tvAdBlockStatus.setText(nowEnabled ? R.string.enabled : R.string.disabled);

        // Notify the browser WebView to refresh its ad-block rules.
        BrowserController controller = BrowserController.getInstance();
        if (controller != null) {
            controller.setAdBlockEnabled(nowEnabled);
        }
    }

    private void onPopUpPlayerToggle() {
        boolean nowEnabled = !MmkvPrefs.getBoolean("popup_player_enabled", true);
        MmkvPrefs.putBoolean("popup_player_enabled", nowEnabled);
        swPopUpPlayer.setChecked(nowEnabled);
        EventBus.getDefault().post(new PopUpPlayerPreferenceChangedEvent());
    }

    /**
     * Shows a single-choice dialog for picking the default browser search engine.
     */
    private void showSearchEngineDialog() {
        AnalyticsTracker.track(this, "setting", "search");
        CharSequence[] engines = getResources().getStringArray(R.array.search_engines);
        int current = PreferenceManager.getSearchEngineIndex(this);

        new AlertDialog.Builder(this)
                .setTitle(R.string.pref_search_engine)
                .setSingleChoiceItems(engines, current, (dialog, which) -> {
                    PreferenceManager.setSearchEngineIndex(this, which);
                    refreshSearchEngineLabel(which, true);
                })
                .setPositiveButton(R.string.btn_ok, null)
                .show();
    }

    /**
     * Updates the search-engine label TextView.
     *
     * @param index     Selected engine index.
     * @param customUrl If true and index == 0, prompt for a custom URL.
     */
    private void refreshSearchEngineLabel(int index, boolean customUrl) {
        String[] engines = getResources().getStringArray(R.array.search_engines);
        if (index == 0 && customUrl) {
            showCustomHomepageDialog();
            return;
        }
        tvSearchEngine.setText(index == 0
                ? getString(R.string.custom_label) + ": " + PreferenceManager.getCustomHomepage(this)
                : (index < engines.length ? engines[index] : ""));
    }

    /** Prompts the user to enter a custom homepage / search URL. */
    private void showCustomHomepageDialog() {
        BrowserUrlDialog.show(this, R.string.pref_search_engine, R.string.pref_search_engine,
                PreferenceManager.getCustomHomepage(this),
                R.string.btn_ok, url -> {
                    PreferenceManager.setCustomHomepage(this, url);
                    tvSearchEngine.setText(getString(R.string.custom_label) + ": " + url);
                });
    }

    private void clearWebCache() {
        AnalyticsTracker.track(this, "setting", "cache");
        WebView webView = new WebView(this);
        webView.clearCache(true);
        webView.destroy();
        Toast.makeText(this, R.string.cache_cleared, Toast.LENGTH_SHORT).show();
    }

    private void confirmClearHistory() {
        AnalyticsTracker.track(this, "setting", "history");
        new AlertDialog.Builder(this)
                .setTitle(R.string.dialog_clear_history_title)
                .setMessage(R.string.dialog_clear_history_message)
                .setPositiveButton(R.string.btn_clear, (dialog, which) -> {
                    Toast.makeText(this, R.string.history_cleared, Toast.LENGTH_SHORT).show();
                    BackgroundExecutor.execute(() -> HistoryDatabase.getInstance().clearAll(this));
                })
                .setNegativeButton(R.string.btn_cancel, null)
                .show();
    }

    private void confirmClearCookies() {
        AnalyticsTracker.track(this, "setting", "cookies");
        new AlertDialog.Builder(this)
                .setTitle(R.string.dialog_clear_cookies_title)
                .setMessage(R.string.dialog_clear_cookies_message)
                .setPositiveButton(R.string.btn_clear, (dialog, which) -> {
                    Toast.makeText(this, R.string.cookies_cleared, Toast.LENGTH_SHORT).show();
                    BackgroundExecutor.execute(() -> CookieManager.getInstance().removeAllCookies(null));
                })
                .setNegativeButton(R.string.btn_cancel, null)
                .show();
    }

    // -------------------------------------------------------------------------
    // Media
    // -------------------------------------------------------------------------

    private void onAutoGalleryToggle() {
        AnalyticsTracker.track(this, "setting", "gallery");
        boolean nowEnabled = !UserPreferences.get(this).isAutoAddToGallery();
        UserPreferences.get(this).setAutoAddToGallery(nowEnabled);
        UserPreferences.get(this).save(this);
        swAutoAddToGallery.setChecked(nowEnabled);
        tvAutoAddToGalleryStatus.setText(nowEnabled ? R.string.enabled : R.string.disabled);
    }

    // -------------------------------------------------------------------------
    // App
    // -------------------------------------------------------------------------

    private void showLanguageDialog() {
        AnalyticsTracker.track(this, "setting", "language");
        new AlertDialog.Builder(this)
                .setSingleChoiceItems(LanguageUtils.LANGUAGE_LABELS,
                        UserPreferences.get(this).getLanguageIndex(),
                        (dialog, which) -> {
                            LanguageUtils.applyLanguage(this, which);
                            dialog.dismiss();
                            finish();
                            EventBus.getDefault().post(new FinishAllActivitiesEvent());
                        })
                .setPositiveButton(R.string.btn_ok, null)
                .show();
    }

    private void openHelp() {
        AnalyticsTracker.track(this, "setting", "how_to");
        startActivity(new Intent(this, HelpActivity.class));
    }

    private void openFeedback() {
        AnalyticsTracker.track(this, "setting", "feedback");
        new FeedbackHelper().openFeedbackForm(this, FeedbackType.GENERAL, "");
    }

    // Reference kept so onResume() can clean it up.
    @Nullable
    private WebViewPresenter webViewPresenterRef;

    private void openPrivacyPolicy() {
        AnalyticsTracker.track(this, "setting", "privacy");
        webViewPresenterRef = new WebViewPresenter();
        webViewPresenterRef.show(this);
        EmailUtils.composeEmail(this, getString(R.string.support_email_subject),
                -0xC7C001 /* accent color */,
                "cameras.ideas@gmail.com");
    }

    private void purchaseRemoveAds() {
        AnalyticsTracker.track(this, "clickRemoveAd", "lifetime");
        if (billingLifecycle != null) {
            billingLifecycle.launchPurchaseFlow(this,
                    BillingUtils.SKU_REMOVE_ADS, "lifetime");
        }
    }

    private void checkOrApplyUpdate() {
        AnalyticsTracker.track(this, "setting", "update");
        if (updateChecker == null || pendingUpdateInfo == null) return;
        updateChecker.startUpdate(this, UpdateInfoUtils.getChangelogText(pendingUpdateInfo),
                pendingUpdateInfo);
        setupUpdateChecker(); // Refresh listener.
    }

    /**
     * Easter-egg: tapping the version label 9 times enables developer/test mode.
     */
    private int devModeTapCount = 0;

    private void onVersionLabelTapped() {
        if (UserPreferences.get(this).isDevModeEnabled() && !BillingUtils.isPremiumBuildFlavor()) {
            showDevMenu();
            return;
        }
        devModeTapCount++;
        if (devModeTapCount >= 9) {
            UserPreferences.get(this).setDevModeEnabled(true);
            UserPreferences.get(this).save(this);
        }
    }

    private void showDevMenu() {
        // Developer-only menu for ad / SDK testing.
        final String[] options = {
                "Disable dev mode",
                "Test: native card ad",
                "Test: interstitial ad",
                "Test: banner ad",
                "Test: MAX mediation suite",
                "Test: app open ad",
                "Clear purchase state",
                "Test: Outbrain ad",
                "Test: rewarded video ad"
        };
        new AlertDialog.Builder(this)
                .setTitle("Developer Menu")
                .setItems(options, (dialog, which) -> {
                    onDevMenuItemSelected(options[which]);
                    dialog.dismiss();
                })
                .show();
    }

    private void onDevMenuItemSelected(@NonNull String option) {
        switch (option) {
            case "Disable dev mode":
                UserPreferences.get(this).setDevModeEnabled(false);
                UserPreferences.get(this).save(this);
                devModeTapCount = 0;
                break;
            case "Test: app open ad":
                AdTestHelper.showOpenAd(this, BuildConfig.VERSION_NAME);
                break;
            case "Test: banner ad":
                AdTestHelper.showBannerAd(this, BuildConfig.VERSION_NAME);
                break;
            case "Test: MAX mediation suite":
                AdTestHelper.launchMaxMediationDebugger(this);
                break;
            case "Test: Outbrain ad":
                AdTestHelper.launchGoogleAdInspector(this);
                break;
            case "Test: native card ad":
                AdTestHelper.showNativeCardAd(this, BuildConfig.VERSION_NAME);
                break;
            case "Test: interstitial ad":
                AdTestHelper.showInterstitialAd(this, BuildConfig.VERSION_NAME);
                break;
            case "Clear purchase state":
                BillingUtils.clearPurchaseState(this);
                break;
            case "Test: rewarded video ad":
                AdTestHelper.showRewardedAd(this, BuildConfig.VERSION_NAME);
                break;
            default:
                Log.w(TAG, "Unknown dev-menu option: " + option);
        }
    }

    // -------------------------------------------------------------------------
    // Billing callback
    // -------------------------------------------------------------------------

    private class PurchaseCallback implements InAppBillingLifecycle.Callback {
        @Override
        public void onPurchaseSuccess() {
            EventBus.getDefault().post(new FinishAllActivitiesEvent());
            finish();
        }

        @Override
        public void onPurchaseRestored() {
            EventBus.getDefault().post(new FinishAllActivitiesEvent());
            finish();
        }

        @Override
        public void onPurchasePending() {
            // No-op: billing flow handles this state internally.
        }
    }

    // -------------------------------------------------------------------------
    // Update checker callback
    // -------------------------------------------------------------------------

    private class UpdateCheckerCallback implements UpdateCheckerListener {
        @Override
        public void onUpdateAvailable(@NonNull UpdateInfo updateInfo) {
            pendingUpdateInfo = updateInfo;
            if (UpdateInfoUtils.isReady(updateInfo)) {
                vCheckUpdate.setVisibility(View.VISIBLE);
            } else if (UpdateInfoUtils.isFlexibleInstallable(updateInfo)) {
                new UpdateManager().promptFlexibleInstall(SettingsActivity.this);
            }
        }

        @Override
        public void onNoUpdateAvailable() {
            new UpdateManager().promptFlexibleInstall(SettingsActivity.this);
        }
    }
}
